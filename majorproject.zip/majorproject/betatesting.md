# Beta Testing
## Person 1 - Asir:
- You should add a title, no idea what the game is
- Also require some sort of instructions to know what the game is talking about.

- what is the difference between inward and front? Same for outward and back? (Need clarification)

- What does the tuck feature do?
- What is the c after the score?

## Person 2 - Meeka:
- Instructions would be nice and some clarification as to how the scoring works (What makes a good dive good, etc)
- What does the jump number mean?
- An ability to go back to the main menu without refreshing the page
- Clarify what the arrow means

## Person 3 - Mia (diver):
- Make the info clearer for a non-diver (instructions)
- Don't use dive numbers for a non-diver
- Make the scores last longer for people to take pictures (bragging rights)

## Person 4 - Quinn (diver):
- Add a pike position
- Add some instruction
