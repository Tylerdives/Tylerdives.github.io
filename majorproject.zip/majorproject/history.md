# History
## December 10, 2018
- Finished proposal
- Started the project
- Started player class
## December 11, 2018
- Added player gravity logic (parabolic path)
- Drawing of pool
## December 14, 2018
- Player rotations
- Tuck position (increases rotational speed)
## December 17, 2018
- Smarter tuck logic, dive numbers
## December 18, 2018
- Dive scoring
## December 19, 2018
- Back, reverse and inward directions
## December 29, 2018
- Dive numbers for all directions
## December 30, 2018
- Score display
## December 30, 2018 - January 1, 2019
- GUI button class
## January 7, 2019
- Fixed button mobile compatibility
## January 8, 2019
- Main menu for game
## January 9, 2019
- Player straight sprite
## January 10, 2019
- Beta testing I
- Player tuck sprite
- Second board height
## January 11, 2019
- Beta testing II
## January 13, 2019
- Beta testing III
- Competition mode
- Dive translation (Diver -> English)
- Back page button
## January 16, 2019
- Re-organised all code

## January 19, 2019
- tutorial
- Rest of comments
